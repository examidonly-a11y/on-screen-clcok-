
# On-Screen Clock (Overlay)

Features:
- Clock overlay with tap-to-hide for 30 minutes (auto reappear).
- Separate date overlay (toggle).
- Thought for the Day between 07:20–08:15; dismissible for the day.
- Background & text opacity sliders saved in preferences.

## Build
1. Open this project in **Android Studio**.
2. Let Gradle sync and run on your device (SDK 34).

Permissions: overlay, foreground service, notifications.
Package: com.rakesh.onscreenclock
